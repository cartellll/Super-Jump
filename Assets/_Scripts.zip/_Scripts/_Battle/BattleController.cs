﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(DamageHPManager))]
public abstract class BattleController : MonoBehaviour
{

    public enum PunchingState
    {
        Fisting,
        Sword
    }

    [SerializeField] protected AnimationClip swordAimationClip;
    [SerializeField] protected AnimationClip fistAimationClip;
    protected AnimationClip currentAnimationClip;

    [SerializeField] protected AnimatorOverrideController animatorOverrideController;

    protected NavMeshAgent agent;
    protected Animator animator;
    protected DamageHPManager damageHpManager;
    protected DamageHPManager targetEnemy;
    protected CrowdStickman enemyCrowd;

    protected bool isBattle = false;

    [Min(0.01f)]
    [SerializeField] protected float reloadTime;

    protected float timerReloadTime;

    protected bool isForceEnemy = false;
    public bool IsBattle
    {
        get
        {
            return isBattle;
        }

        set
        {
            isBattle = value;
            if (isBattle == true)
            {
                agent.enabled = true;
            }

            else
            {
                agent.enabled = false;
                targetEnemy = null;
            }
        }
    }

    protected virtual void Init()
    {
        currentAnimationClip = fistAimationClip;
        animator = GetComponent<Animator>();
        animatorOverrideController = new AnimatorOverrideController(animator.runtimeAnimatorController);
        animator.runtimeAnimatorController = animatorOverrideController;

        timerReloadTime = 0;
        agent = GetComponent<NavMeshAgent>();
        damageHpManager = GetComponent<DamageHPManager>();
        IsBattle = false;

        animator.SetFloat("PunchSpeed", currentAnimationClip.length / reloadTime);
    }


    protected virtual void UpdateBattle()
    {
        if (!isBattle)
        {
            return;
        }

        if (GameManager.Instance.state != GameManager.State.Play)
        {
            return;
        }

        if (targetEnemy != null && targetEnemy.HP > 0)
        {
            Vector3 vectorToTarget = targetEnemy.transform.position - gameObject.transform.position;
            

            if (new Vector2(vectorToTarget.x,vectorToTarget.z).magnitude > 0.2f + transform.localScale.x / 3.5f + targetEnemy.transform.localScale.x / 3.5f)
            {
                MoveToEnemy();
            }
            else
            {
                transform.rotation = Quaternion.LookRotation(vectorToTarget.normalized);
                timerReloadTime -= Time.deltaTime;
                if (timerReloadTime <= 0)
                {
                    AttackEnemy();
                    timerReloadTime = reloadTime;
                }
            }
        }
        else
        {
            isForceEnemy = false;
            ChangeTargetEnemy();
        }
    }

    protected virtual void MoveToEnemy()
    {
        animator.SetBool("Run", true);
        animator.SetBool("Punching", false);
        if (agent.isOnNavMesh)
        {
            agent.SetDestination(targetEnemy.transform.position);
        }
    }

    protected virtual void AttackEnemy()
    {
        if (agent.isOnNavMesh)
        {
            agent.SetDestination(transform.position);
        }
        animator.SetBool("Run", false);
        animator.SetBool("Punching", true);

        targetEnemy.HP -= damageHpManager.Damage;
        targetEnemy.ActivateHitEffect();
    }
    protected virtual void ChangeTargetEnemy()
    {
        if (enemyCrowd.GetCount() != 0)
        {
            targetEnemy = enemyCrowd.GetStickmanByIndex(Random.Range(0, enemyCrowd.GetCount()));
            animator.SetBool("Punching", false);
            animator.SetBool("Run", true);
        }
        else
        {
            if (agent.isOnNavMesh)
            {
                agent.SetDestination(transform.position);
            }
            animator.SetBool("Punching", false);
            animator.SetBool("Run", false);
        }
    }

 
    public void ChangeAnimationAttack(PunchingState state)
    {
        switch (state)
        {
            case PunchingState.Fisting:
                currentAnimationClip = fistAimationClip;
                break;
            case PunchingState.Sword:
                currentAnimationClip = swordAimationClip;
                break;
        }
        animatorOverrideController["Punching"] = currentAnimationClip;
        animator.SetFloat("PunchSpeed", currentAnimationClip.length / reloadTime);
    }

}