﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Billboard : MonoBehaviour
{
    public Camera Camera;

    private void Awake()
    {
        if (Camera == null) Camera = Camera.main;
    }

    private void LateUpdate()
    {
        transform.LookAt(transform.position + Camera.transform.rotation * Vector3.forward,
            Camera.transform.rotation * Vector3.up);
    }
}