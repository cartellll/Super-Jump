﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using YsoCorp.GameUtils;
public class GameManager: MonoBehaviour
{
    public CoreConfig CoreConfig;
    
    public InputManager InputManager;
    public LevelManager LevelManager;
    public SoundManager SoundManager;
  //  public SoundManager SoundManager;
  
    public static GameManager Instance { get; private set; }

    public enum State
    {
        Start,
        Play,
        Finish,
        Pause
    }
    public State state { get; private set; }

    [Header("IronSource")]
    public IronSourceController ironSourceController;

    [Header("SaveLoad")]
    public SaveLoadController mSaveLoad;

    //public List<string> crateNames = new List<string>();

    [Header("UI")]
    public UIBaseScreen windowStart;
    public UIBaseScreen windowFail;
    public UIBaseScreen windowFinish;
    public UIBaseScreen gamePlayScreen;
    //public GameObject windowPlay;
    [SerializeField] private float timeBetweenFinishAndShowWindow = 3;
    //private readonly CompositeDisposable _lifetimeDisposables = new CompositeDisposable();


    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }

        mSaveLoad.InitiateClass();
        int levelIndex = mSaveLoad.GetLevelNumber();
        LevelManager.LoadLevel(CoreConfig.Levels[levelIndex], levelIndex);
      
      //  EventManager.StartListening<bool>(CoreLevelEvents.Finish, Finish);
      //  EventManager.StartListening<bool>(CoreLevelEvents.Fail, GameOver);
    }
    private void Start()
    {
        
        YCManager.instance.OnGameStarted(LevelManager.CurrentLevelIndex);
        windowStart.Init();

        windowStart.Show();
        state = State.Start;

        Time.timeScale = 0;
    }

    private void Update()
    {
        if(state == State.Play)
        {
            if(LevelManager.CurrentLevel.PlayerCrowd.GetCount() == 0)
            {
                GameOver();
            }

            else if(LevelManager.CurrentLevel.EnemyCrowd.GetCount() == 0)
            {
                Finish();
            }
        }
    }

    public void ClickStart()
    {
        SoundManager.AudioClickButton.Play();
        windowStart.Hide();
        gamePlayScreen.Show();
        StartCoroutine(HideWindowHandler());
        Time.timeScale = 1;
       
    }

    private IEnumerator HideWindowHandler()
    {
        yield return new WaitForSeconds(0.05f);
        state = State.Play;
    }

    private void Finish()
    {
        YCManager.instance.OnGameFinished(true);
        state = State.Finish;
        mSaveLoad.SetLevelNumber(mSaveLoad.GetLevelNumber() + 1);
        mSaveLoad.SaveParametrs();
        gamePlayScreen.Hide();
        StartCoroutine(OpenFinishWindow(windowFinish));
       
        if (mSaveLoad.GetLevelNumber() == CoreConfig.Levels.Length)
        {
            mSaveLoad.SetLevelNumber(0);
            mSaveLoad.SaveParametrs();
        }

        GAManager.Instance.OnFinishLevel(mSaveLoad.GetLevelNumber() + 1);
        
    }

    private void GameOver()
    {
        YCManager.instance.OnGameFinished(false);
        GAManager.Instance.OnFailedLevel(mSaveLoad.GetLevelNumber() + 1);
        state = State.Finish;
        gamePlayScreen.Hide();
        StartCoroutine(OpenFinishWindow(windowFail));
    }

    
    IEnumerator OpenFinishWindow(UIBaseScreen screen)
    {
        yield return new WaitForSeconds(timeBetweenFinishAndShowWindow);
        screen.Show();
        Time.timeScale = 0;
    }


    public void Restart()
    {
        //adManager.ShowAd();
        SoundManager.AudioClickButton.Play();
        SceneManager.LoadScene("Naruto");
    }

    public void NextButton()
    {
        SoundManager.AudioClickButton.Play();
      /*  if ((mSaveLoad.GetLevelNumber()) % 2 == 0)
        {
           ironSourceController.ShowInterstitial();
        }*/

        SceneManager.LoadScene("Naruto");
    }

    /*  private void OnApplicationPause(bool pause)
      {
          IronSource.Agent.onApplicationPause(pause);
      }*/


    /*  private void OnDisable()
      {
          EventManager.StopListening<bool>(CoreLevelEvents.Finish, Finish);
          EventManager.StopListening<bool>(CoreLevelEvents.Fail, GameOver);
          _lifetimeDisposables.Clear();
      }*/
}

