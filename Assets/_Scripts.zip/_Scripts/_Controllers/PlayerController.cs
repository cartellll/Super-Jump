﻿using System.Collections;
using System.Collections.Generic;
using SuperStars.Events;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private PlayerConfig config;
    [SerializeField] private PlayerStickmanController controlledStickman;
    [SerializeField] private LineRendererController lineRendererController;

    public PlayerStickmanController ControlledStickman => controlledStickman;
    [SerializeField] private GameField gameField;

    private Vector3 prevInputPosition;

    private LevelController levelController;

    private bool isInit = false;
    private void Start()
    {
        Init();
    }

    private void OnEnable()
    {
        EventManager.StartListening<Vector3>(InputEvents.Input_Start, OnInputStart);
        EventManager.StartListening<Vector3>(InputEvents.Input_Update, OnInputUpdate);
        EventManager.StartListening<Vector3>(InputEvents.Input_End, OnInputEnd);   
    }

    private void OnDisable()
    {
        EventManager.StopListening<Vector3>(InputEvents.Input_Start, OnInputStart);
        EventManager.StopListening<Vector3>(InputEvents.Input_Update, OnInputUpdate);
        EventManager.StopListening<Vector3>(InputEvents.Input_End, OnInputEnd);
    }

    public void Init()
    {
        if(isInit)
        {
            return;
        }

        levelController = GameManager.Instance.LevelManager.CurrentLevel;
        if (controlledStickman == null)
        {
            controlledStickman = Instantiate(config.PlayerStickmans, gameField.InstantinatePosition.position ,Quaternion.identity,null);
            controlledStickman.SetSize(Random.Range(0, config.PlayerStickmanConfig.NumberOfSizes-1));
        }
        controlledStickman.Init();
        controlledStickman.SetIsControlledStickman(true);
        

        if (!levelController.PlayerCrowd.Contains(controlledStickman.GetDamageHPManager))
        {
            levelController.PlayerCrowd.AddStickman(controlledStickman.GetDamageHPManager);
        }

        lineRendererController?.Init();
        lineRendererController?.UpdateLineRenderer(controlledStickman.transform);

        isInit = true;
    }

    private void OnInputStart(Vector3 inputPosition)
    {
        if (GameManager.Instance.state != GameManager.State.Play)
        {
            return;
        }

        prevInputPosition = GetScreenToGroundPoint(inputPosition);
    }

    private void OnInputUpdate(Vector3 inputPosition)
    {
        if (GameManager.Instance.state != GameManager.State.Play)
        {
            return;
        }

        if (controlledStickman == null)
        {
            return;
        }

        lineRendererController?.UpdateLineRenderer(controlledStickman.transform);

        Vector3 screenToGroundPoint = GetScreenToGroundPoint(inputPosition);
        float newStickmanPositionX = controlledStickman.transform.position.x + (screenToGroundPoint.x - prevInputPosition.x);
        float clampX = Mathf.Clamp(newStickmanPositionX, gameField.LeftPlayerLimit.position.x, gameField.RightPlayerLimit.position.x);
        controlledStickman.transform.position = new Vector3(clampX, controlledStickman.transform.position.y, controlledStickman.transform.position.z);
        prevInputPosition = screenToGroundPoint;
    }

    private void OnInputEnd(Vector3 inputPosition)
    {
        if (GameManager.Instance.state != GameManager.State.Play)
        {
            return;
        }

        if (controlledStickman == null)
        {
            return;
        }

        controlledStickman.StartControlledSitckman();
        controlledStickman = null;

        StartCoroutine(InstantinateStickman());
    }

    private Vector3 GetScreenToGroundPoint(Vector3 screenPoint)
    {
        float screnToGroundDistance = 0;
        Camera camera = Camera.main;
        int layerMask = LayerMask.GetMask("Ground");
        RaycastHit hit;
        Ray ray = camera.ScreenPointToRay(screenPoint);
        if (Physics.Raycast(ray, out hit, 100, layerMask))
        {
            screnToGroundDistance = hit.distance;
        }
        return camera.ScreenToWorldPoint(new Vector3(screenPoint.x, screenPoint.y, screnToGroundDistance));
    }

    private IEnumerator InstantinateStickman()
    {
        yield return new WaitForSeconds(config.TimeToRestartStickman);

        controlledStickman = Instantiate(config.PlayerStickmans, gameField.InstantinatePosition.position, Quaternion.identity, null);
        controlledStickman.Init();
        controlledStickman.SetIsControlledStickman(true);
        controlledStickman.SetSize(Random.Range(0, config.PlayerStickmanConfig.NumberOfSizes-1));
        controlledStickman.UpdateParametrs();
        levelController.PlayerCrowd.AddStickman(controlledStickman.GetDamageHPManager);

        lineRendererController?.UpdateLineRenderer(controlledStickman.transform);

    }

    private void OnDestroy()
    {
        if(controlledStickman != null)
        {
            EventManager.TriggerEvent(DeathEvents.Death_stickman, controlledStickman.GetDamageHPManager);
            Destroy(controlledStickman.gameObject);
        }
    }
}
