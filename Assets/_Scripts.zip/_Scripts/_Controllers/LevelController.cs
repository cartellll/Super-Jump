﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelController : MonoBehaviour
{
    public enum LevelState
    {
        Start,
        Battle,
        Finish
    }
    private LevelState levelState = LevelState.Start;

    public LevelState GetLevelState => levelState;

    [SerializeField] private PlayerController playerController;

    public PlayerController PlayerController => playerController;

    [SerializeField] private CrowdStickman playerCrowd;
    [SerializeField] private CrowdStickman enemyCrowd;

    public CrowdStickman PlayerCrowd => playerCrowd;
    public CrowdStickman EnemyCrowd => enemyCrowd;

    [SerializeField] private GameField gameField;
    public GameField GameField => gameField;
   

    public void StartBattle()
    {
        if(levelState != LevelState.Start)
        {
            return;
        }
        

        Destroy(playerController.gameObject);
        levelState = LevelState.Battle;
        gameField.WallBetweenEnemyAndPlayer.SetActive(false);
    }
    /* public GameObject Finish;

     [Header("EnemyPrefabs")]
     public List<EnemyConfig> enemyConfigList = new List<EnemyConfig>();

     private Transform SpawnPointsOrder;

     private void Start()
     {
         if (transform.Find("SpawnPoints") != null)
         {
             SpawnPointsOrder = transform.Find("SpawnPoints").transform;
             InitEnemies();
         }
     }
     public List<PointController> GetSpawnPoints(string Tag)
     {
         var pointManagers = SpawnPointsOrder.GetComponentsInChildren<PointManager>();

         List<PointController> points = new List<PointController>();
         foreach (var pointManager in pointManagers)
         {
             if (pointManager.tag == Tag)
             {
                 points = pointManager.GetSpawnPoints();
             }
         }
         return points;
     }

     public GameObject GetEnemyPrefab(EnemyType type)
     {
         GameObject tempEnemyPrefab = null;
         foreach (EnemyConfig enemyConfig in enemyConfigList)
         {
             if (enemyConfig.Type == type)
             {
                 tempEnemyPrefab = enemyConfig.Prefab;
             }
         }
         return tempEnemyPrefab;
     }


     private void SpawnBot(EnemyType type, Transform pointTransform)
     {
         GameObject enemyPrefab;
         enemyPrefab = GetEnemyPrefab(type);
         Instantiate(enemyPrefab, pointTransform);

     }

     public void InitEnemies()
     {
         foreach (EnemyConfig tempConfig in enemyConfigList)
         {
             List<PointController> points = null;

             points = GetSpawnPoints(tempConfig.Type.ToString());

             if (points != null)
             {
                 foreach (PointController point in points)
                 {
                     Instantiate(tempConfig.Prefab, point.transform);
                 }
             }
         }
     }*/
}
