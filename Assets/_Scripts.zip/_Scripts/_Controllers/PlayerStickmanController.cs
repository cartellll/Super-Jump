﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SuperStars.Events;
using UnityEngine.AI;


[RequireComponent(typeof(BoxCollider), typeof(DamageHPManager))]
public class PlayerStickmanController : MonoBehaviour
{
    [Header("Config")]
    [SerializeField] private PlayerStickmanConfig config;

    private DamageHPManager damageHpManager;
    public DamageHPManager GetDamageHPManager => damageHpManager;

    [Min(0)]
    [SerializeField] private int size = 0;
   
    private Rigidbody rigidBody;

    [SerializeField] private Rigidbody spineRigidBody;

    private Collider[] colliders;

    [SerializeField] private GameObject ragdollStickman;


    [SerializeField] private RagdollHelper ragdollHelper;

    [Header("BattleController")]
    [SerializeField] private PlayerBattleController battleController;
    public PlayerBattleController BattleController => battleController;

    [Header("Animator")]
    [SerializeField] private Animator animator;

    [Header("Armor")]
    [SerializeField] private GameObject shield;
    [SerializeField] private GameObject shelmet;
    [SerializeField] private GameObject sword;

    public GameObject Shield => shield;
    public GameObject Shelmet => shelmet;
    public GameObject Sword => sword;

    private bool isControlled = false;

    private LevelController levelController;

    private float speed;
    private bool _isInit = false;
    private void Awake()
    {
        damageHpManager = GetComponent<DamageHPManager>();
        colliders = ragdollStickman.GetComponentsInChildren<Collider>();
    }

    private void Start()
    {
        Init();
    }

    public void Init()
    {
        if(_isInit)
        {
            return;
        }

        levelController = GameManager.Instance.LevelManager.CurrentLevel;
        UpdateParametrs();
        if (sword.activeSelf)
        {
            battleController.ChangeAnimationAttack(global::BattleController.PunchingState.Sword);
        }
         rigidBody = spineRigidBody;

        _isInit = true;
    }

    private void OnEnable()
    {
        EventManager.StartListening<DamageHPManager>(DeathEvents.Death_stickman,OnDead);
    }

    private void OnDisable()
    {
        EventManager.StopListening<DamageHPManager>(DeathEvents.Death_stickman, OnDead);
    }

    private void Update()
    {

        if(GameManager.Instance.state == GameManager.State.Finish && !animator.GetCurrentAnimatorStateInfo(0).IsName("Dance"))
        {
            battleController.IsBattle = false;
            transform.LookAt(Vector3.back);
            animator.SetBool("Dance", true);
        }

        else
        {
            animator.SetBool("Dance", false);
        }

        if (GameManager.Instance.state != GameManager.State.Play)
        {
            return;
        }

        if (levelController.GetLevelState == LevelController.LevelState.Battle)
        {
            if(animator.GetCurrentAnimatorStateInfo(0).IsName("Stand_up_from_back") || animator.GetCurrentAnimatorStateInfo(0).IsName("Stand_up _from_belly") || ragdollHelper.ragdolled)
            {
                battleController.IsBattle = false;
            }
            else if (battleController != null && !battleController.IsBattle && (animator.GetCurrentAnimatorStateInfo(0).IsName("Idle") || animator.GetCurrentAnimatorStateInfo(0).IsName("Run")))
            {
                RemoveRigidBodyOnParent();
                battleController.IsBattle = true;
            }
        }
    }

    private Vector3 velocityBeforePhysicsUpdate;
    void FixedUpdate()
    {
        velocityBeforePhysicsUpdate = rigidBody.velocity;
    }

    public void SetEnabled(bool isEnabled)
    {
        foreach (var collider in colliders)
        {
            collider.enabled = isEnabled;
        }
    }

    public void StartControlledSitckman()
    {
        rigidBody.isKinematic = false;
        rigidBody.AddForce(Vector3.forward * speed);
        SetRunAnimState();
    }

    public void SetSize(int size)
    {
        this.size = size;
    }

    public void UpdateParametrs()
    {
        if (size < config.NumberOfSizes)
        {
            UpdateColorMaterial();
            UpdateSpeed();
            UpdateScale();
            UpdateHP();
            UpdateDamage();
        }
    }
    public void UpdateColorMaterial()
    {
        GetComponentInChildren<SkinnedMeshRenderer>().material = config.PlayerStickmansMaterials[size];
        shield.GetComponentInChildren<MeshRenderer>().material = config.PlayerStickmansMaterials[size];
        shelmet.GetComponentInChildren<MeshRenderer>().material = config.PlayerStickmansMaterials[size];
        sword.GetComponentInChildren<MeshRenderer>().material = config.PlayerStickmansMaterials[size];
    }

    public void UpdateScale()
    {
        transform.localScale = Vector3.one * config.PlayerStickmansScales[size];
    }

    public void UpdateSpeed()
    {
        speed = config.PlayerStickmansSpeeds[size];
    }

    public void UpdateHP()
    {
        damageHpManager.HP = config.PlayerStickmansHP[size];
    }

    public void UpdateDamage()
    {
        damageHpManager.Damage = config.PlayerStickmansDamage[size];
    }

    public void ActRagdollCollision(Collision collision)
    {
        if (levelController.GetLevelState == LevelController.LevelState.Battle)
        {
            return;
        }

        var tempStickman = collision.gameObject.GetComponentInParent<PlayerStickmanController>();

        if (tempStickman == null || velocityBeforePhysicsUpdate.sqrMagnitude <= tempStickman.velocityBeforePhysicsUpdate.sqrMagnitude)
        {
            return;
        }

        if(tempStickman.gameObject == gameObject)
        {
            return;
        }

        if (size == tempStickman.size)
        {
            
            Vector3 force = Vector3.forward * velocityBeforePhysicsUpdate.magnitude * config.CollisionImpulse + Vector3.up * config.UpCollisionImpulse;

            tempStickman.GrowingUpStickman(this);
            tempStickman.ActivateRagdoll();
            
     
            tempStickman.spineRigidBody.AddForce(force);
            
            tempStickman.StartCoroutine(tempStickman.StickmanWakeUp());

            if (tempStickman.size > 0)
            {
                GameObject effect = Instantiate(config.PlayerStickmansMergeEffect[tempStickman.size - 1], collision.contacts[0].point, Quaternion.identity, null);
                Destroy(effect, 2);
            }
            
            EventManager.TriggerEvent(DeathEvents.Death_stickman, damageHpManager);
            Destroy(gameObject);
        }

        else
        {
            if (isControlled || tempStickman.isControlled)
            {
                GameObject effect = Instantiate(config.NoMergeEffect, collision.contacts[0].point, Quaternion.identity, null);
                Destroy(effect, 2);
            }

            Vector3 force = -collision.contacts[0].normal * velocityBeforePhysicsUpdate.magnitude * config.CollisionImpulse;

            ActivateRagdoll();
            spineRigidBody.AddForce(-force/2f);
            StartCoroutine(StickmanWakeUp());
            tempStickman.ActivateRagdoll();
            tempStickman.StartCoroutine(tempStickman.StickmanWakeUp());
            tempStickman.spineRigidBody.AddForce(force);
        }
        
    }
    private void OnCollisionEnter(Collision collision)
    {
        ActRagdollCollision(collision);

        if(collision.gameObject.tag == "WallBetweenEnemy" && isControlled)
        {
            SetIsControlledStickman(false);
            animator.SetBool("Run", false);
        }
    }

    public void AddBounce(ArmorBounce armorBounce)
    {
        GameObject armor = null;
        switch ((int)armorBounce.GetTypeArmor)
        {
            case 0:
                armor = Shield.gameObject;
                break;
            case 1:
                armor = sword.gameObject;
                battleController.ChangeAnimationAttack(global::BattleController.PunchingState.Sword);
                break;
            case 2:
                armor = shelmet.gameObject;
                break;
        }

        if (armor != null)
        {
            armor.SetActive(true);
            //armor.GetComponentInChildren<MeshRenderer>().material = armorBounce.gameObject.GetComponentInChildren<MeshRenderer>()?.material;
        }

        damageHpManager.HP += armorBounce.HpBounce;
        damageHpManager.Damage += armorBounce.DamageBounce;
    }
   

    private void GrowingUpStickman(PlayerStickmanController prevStickman)
    {
        if (size < config.NumberOfSizes-1)
        {
            size++;
            UpdateParametrs();
        }

        GameObject prevStickmanShield = prevStickman.shield.gameObject;
        GameObject prevStickmanSword = prevStickman.sword.gameObject;
        GameObject prevStickmanShelmet = prevStickman.shelmet.gameObject;

        if (prevStickmanShield.activeSelf)
        {
            shield.gameObject.SetActive(true);
        }

        if (prevStickmanSword.activeSelf)
        {
            sword.gameObject.SetActive(true);
            battleController.ChangeAnimationAttack(global::BattleController.PunchingState.Sword);
        }

        if (prevStickmanShelmet.activeSelf)
        {
            shelmet.gameObject.SetActive(true);
        }

        damageHpManager.HP += (prevStickman.damageHpManager.HP - config.PlayerStickmansHP[prevStickman.size]);
        damageHpManager.Damage += (prevStickman.damageHpManager.Damage - config.PlayerStickmansDamage[prevStickman.size]);
    }

    private void ActivateRagdoll()
    {
        if (isControlled)
        {
            SetIsControlledStickman(false);
            animator.SetBool("Run", false);
        }

        ragdollHelper.ragdolled = true;
    }

    public void SetRunAnimState()
    {
        animator.SetBool("Run", true);
    }

   
    public void SetIsControlledStickman(bool isControlled)
    {
        if (isControlled)
        {
            foreach(Transform childTransform in GetComponentsInChildren<Transform>())
            {
                childTransform.gameObject.layer = LayerMask.NameToLayer("StartStickman");
            }

            AddRigidBodyOnParent();
        }
        else
        {
            foreach (Transform childTransform in GetComponentsInChildren<Transform>())
            {
                childTransform.gameObject.layer = LayerMask.NameToLayer("PlayerStickman");
            }

            RemoveRigidBodyOnParent();
        }
        this.isControlled = isControlled;
    }

    private void RemoveRigidBodyOnParent()
    {
        if (GetComponent<Rigidbody>() == null)
        {
            return;
        }

        Destroy(GetComponent<Rigidbody>());
        GetComponent<BoxCollider>().enabled = false;
        rigidBody = spineRigidBody;
        SetEnabled(true);
    }

    private void AddRigidBodyOnParent()
    {
        if(GetComponent<Rigidbody>() != null)
        {
            return;
        }

        SetEnabled(false);
        rigidBody = gameObject.AddComponent<Rigidbody>();
        rigidBody.isKinematic = true;
        rigidBody.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
        GetComponent<BoxCollider>().enabled = true;
    }

    private void OnDead(DamageHPManager tempDamageHpManager)
    {
        if(damageHpManager == tempDamageHpManager)
        {
            StartCoroutine(Dead());
        }
    }

    public IEnumerator Dead()
    {
        damageHpManager.ActivateDeathEffect();
        battleController.IsBattle = false;
        ragdollHelper.ragdolled = true;
        yield return new WaitForSeconds(2);
        Destroy(gameObject);
    }
 
    private IEnumerator StickmanWakeUp()
    {
        yield return new WaitForSeconds(config.TimeToRagdollUp);
        ragdollHelper.ragdolled = false;
    }

   /* private Vector3 ParabollVel(Transform target, Transform origin, float angle)
    {
        
        Vector3 dir = Vector3.zero - origin.position;  // get target direction
        float h = dir.y;  // get height difference
        dir.y = 0;  // retain only the horizontal direction
        float dist = dir.magnitude;  // get horizontal distance
        float a = angle * Mathf.Deg2Rad;  // convert angle to radians
        dir.y = dist * Mathf.Tan(a);  // set dir to the elevation angle
        dist += h / Mathf.Tan(a);  // correct for small height differences
                                   // calculate the velocity magnitude
        float vel = Mathf.Sqrt(dist * Physics.gravity.magnitude / Mathf.Sin(2 * a));
        return vel * dir.normalized;
    }*/
}
