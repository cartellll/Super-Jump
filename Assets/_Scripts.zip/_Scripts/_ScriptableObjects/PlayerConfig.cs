﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Player Config",menuName = "Configs/Player Config")]
public class PlayerConfig : ScriptableObject
{
    [SerializeField] private PlayerStickmanController playerStickmanPrefabs;

    [SerializeField] private PlayerStickmanConfig playerStickmanConfig;

    [Min(0)]
    [SerializeField] private float timeToRestartStickman;

    public PlayerStickmanController PlayerStickmans => playerStickmanPrefabs;
    public PlayerStickmanConfig PlayerStickmanConfig => playerStickmanConfig;

    public float TimeToRestartStickman => timeToRestartStickman;
}
