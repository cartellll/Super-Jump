﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[CreateAssetMenu(fileName = "Player Stickman Config", menuName = "Configs/Player Stickman Config")]
public class PlayerStickmanConfig : ScriptableObject
{

    [Min(0)]
    [SerializeField] private int numberOfSizes;

    [Min(0)]
    [SerializeField] private float timeToRagdollUp;

    [Min(0)]
    [SerializeField] private float collisionImpulse;

    [SerializeField] private float upCollisionImpulse;

    [SerializeField] private GameObject noMergeEffect;
   
    

    [SerializeField] private Material[] playerStickmanMaterials;
    [SerializeField] private float[] playerStickmanScales;
    [SerializeField] private float[] playerStickmanSpeeds;
    [SerializeField] private float[] playerStickmanHP;
    [SerializeField] private float[] playerStickmanDamage;
    [SerializeField] private GameObject[] playerStickmanMergeEffect;


    public int NumberOfSizes => numberOfSizes;
    public float TimeToRagdollUp => timeToRagdollUp;
    public float CollisionImpulse => collisionImpulse;
    public float UpCollisionImpulse => upCollisionImpulse;
    public GameObject NoMergeEffect => noMergeEffect;
    public Material[] PlayerStickmansMaterials => playerStickmanMaterials;
    public float[] PlayerStickmansScales => playerStickmanScales;
    public float[] PlayerStickmansSpeeds => playerStickmanSpeeds;
    public float[] PlayerStickmansHP => playerStickmanHP;
    public float[] PlayerStickmansDamage => playerStickmanDamage;
    public GameObject[] PlayerStickmansMergeEffect => playerStickmanMergeEffect;
    void OnValidate()
    {
        if (numberOfSizes!= 0 && playerStickmanMaterials.Length != numberOfSizes)
        {
            Debug.LogWarning("Don't change the 'ints' field's array size!");
            Array.Resize(ref playerStickmanMaterials, numberOfSizes);
            Array.Resize(ref playerStickmanScales, numberOfSizes);
            Array.Resize(ref playerStickmanSpeeds, numberOfSizes);
            Array.Resize(ref playerStickmanHP, numberOfSizes);
            Array.Resize(ref playerStickmanDamage, numberOfSizes);
            Array.Resize(ref playerStickmanMergeEffect, numberOfSizes-1);
        }
    }
}