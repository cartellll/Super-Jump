﻿namespace SuperStars.Enums
{
    public enum UpdateType
    {
       Update,FixedUpdate,LateUpdate 
    }
}