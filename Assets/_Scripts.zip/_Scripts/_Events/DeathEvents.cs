﻿public static class DeathEvents
{
    public static string Death_stickman = "Death_stickman";
}