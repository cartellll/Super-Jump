﻿public static class BattleEvents
{
    public static string Detection_enemy = "Detection_enemy";
}
