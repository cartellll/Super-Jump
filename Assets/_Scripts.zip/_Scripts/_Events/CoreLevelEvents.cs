﻿public static class CoreLevelEvents
{
    public static string Finish = "Finish";
    public static string Fail = "Fail";
    public static string StartBattle = "StartBattle";
}