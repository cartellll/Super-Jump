﻿public static class InputEvents
{
    public static string Input_Start = "InputStart";
    public static string Input_Update = "InputUpdate";
    public static string Input_End = "InputEnd";
    public static string Joystick_Output = "Joystick_Output";
}
