﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using SuperStars.Events;

public class Enemy : MonoBehaviour
{
    
    [SerializeField] private Animator animator;
    [SerializeField] private SimpleRagdollHelper ragdollHelper;
    [SerializeField] private EnemyBattleController battleController;
    [SerializeField] private DamageHPManager damageHpManager;

    [SerializeField] private float startSpeed;

    private float attackPositionZ;

    private enum State
    {
        Run,
        Battle
    }
    private State state = State.Run;

    private void Start()
    {
        ragdollHelper.Init();
        ragdollHelper.ragdolled = false;
        attackPositionZ = GameManager.Instance.LevelManager.CurrentLevel.GameField.EnemyAttackTrigger.transform.position.z;
    }

    private void OnEnable()
    {
        EventManager.StartListening<DamageHPManager>(DeathEvents.Death_stickman, OnDead);
    }

    private void OnDisable()
    {
        EventManager.StopListening<DamageHPManager>(DeathEvents.Death_stickman, OnDead);
    }
    
   

    void Update()
    {


        if (GameManager.Instance.state == GameManager.State.Finish && !animator.GetCurrentAnimatorStateInfo(0).IsName("Dance"))
        {
            battleController.IsBattle = false;
            transform.LookAt(Vector3.back);
            animator.SetBool("Dance", true);
        }
        else
        {
            animator.SetBool("Dance", false);
        }

        if (GameManager.Instance.state != GameManager.State.Play)
        {
            return;
        }

        switch (state)
        {
            case State.Run:
                Run();
                break;

            case State.Battle:
                break;
        }
    }

    private void Run()
    {
        // agent.SetDestination(Vector3.zero);

        animator.SetBool("Run", true);
        transform.position += Vector3.back * startSpeed * Time.deltaTime;

        if(transform.position.z < attackPositionZ || GameManager.Instance.LevelManager.CurrentLevel.GetLevelState == LevelController.LevelState.Battle)
        {
            if (battleController != null)
            {
                GameManager.Instance.LevelManager.CurrentLevel.StartBattle();
                battleController.IsBattle = true;
                state = State.Battle;
            }
        }
    }

    private void OnDead(DamageHPManager tempDamageHpManager)
    {
        if (damageHpManager == tempDamageHpManager)
        {
            StartCoroutine(Dead());
        }
    }

    public IEnumerator Dead()
    {
        damageHpManager.ActivateDeathEffect();
        battleController.IsBattle = false;
        ragdollHelper.ragdolled = true;
        yield return new WaitForSeconds(2);
        Destroy(gameObject);
    }
}
